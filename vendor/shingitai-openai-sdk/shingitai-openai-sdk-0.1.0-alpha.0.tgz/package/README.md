# ShinGiTaI OpenAi TypeScript SDK

Official TypeScript SDK for the ShinGiTaI OpenAi Gateway.

The SDK is local-first, provider-independent, browser-compatible, and Node-compatible
on runtimes with `fetch`.

## Install

Workspace usage:

```bash
pnpm --filter @shingitai/openai-sdk install
pnpm --filter @shingitai/openai-sdk build
```

When published, install it from the package registry used by ShinGiTaI:

```bash
pnpm add @shingitai/openai-sdk
```

## Create A Client

```ts
import { createShinGiTaiClient } from "@shingitai/openai-sdk";

const client = createShinGiTaiClient({
  baseUrl: "http://127.0.0.1:8000",
  apiKey: process.env.SHINGITAI_API_KEY,
  timeoutMs: 30_000,
  retry: {
    maxAttempts: 2,
  },
});
```

The SDK does not read key files and does not store keys on disk. Pass the API key
from the application environment or secret manager that owns runtime config.

## Local Config

```ts
const client = createShinGiTaiClient({
  baseUrl: "http://127.0.0.1:8000",
  apiKey: process.env.SHINGITAI_API_KEY,
});
```

## Staging Config

```ts
const client = createShinGiTaiClient({
  baseUrl: "https://shingitai-openai-staging.onrender.com",
  apiKey: process.env.SHINGITAI_API_KEY,
});
```

Render staging may need a wake-up period. The SDK uses normal HTTPS and does not
support insecure SSL bypass.

## Health

```ts
const health = await client.health();
const ready = await client.ready();
```

These calls do not send the API key.

## Models

```ts
const models = await client.listModels();
console.log(models.data);
```

`GET /v1/models` requires a Bearer API key.

## Chat

```ts
const response = await client.chat({
  model: "shingitai-mock",
  messages: [
    {
      role: "user",
      content: "Explain Python automation and testing.",
    },
  ],
});

console.log(response.choices[0]?.message.content);
```

## Chat With Core Context

```ts
const response = await client.chat({
  model: "shingitai-mock",
  messages: [
    {
      role: "user",
      content: "Explain Python automation and testing.",
    },
  ],
  use_core_context: true,
  core_projects: ["core_programming_python"],
  core_context_limit: 5,
  core_context_max_chars: 5000,
});

console.log(response.core_context?.sources);
```

## Core Context

```ts
const context = await client.coreContext({
  question: "What are good API security principles?",
  projects: ["core_software_architecture_security"],
  limit: 5,
  max_chars: 5000,
});

console.log(context.context);
```

## Usage

```ts
const usage = await client.getUsage();
console.log(usage.tokens_this_month, usage.token_limit);
```

`getUsage()` maps to `GET /v1/account/usage`.

## Error Handling

```ts
import {
  ApiResponseError,
  AuthenticationError,
  RateLimitError,
  ShinGiTaiError,
  TimeoutError,
} from "@shingitai/openai-sdk";

try {
  await client.listModels();
} catch (error) {
  if (error instanceof AuthenticationError) {
    // Missing, invalid, or disabled API key.
  } else if (error instanceof RateLimitError) {
    // 429 from the API.
  } else if (error instanceof TimeoutError) {
    // Client-side timeout.
  } else if (error instanceof ApiResponseError) {
    // Non-2xx API response.
  } else if (error instanceof ShinGiTaiError) {
    // Any SDK-normalized error.
  }
}
```

Error objects expose `message`, `status`, `code`, `requestId`, `details`, and
`cause` when available. API keys are redacted from normalized error messages and
details.

## Timeout And AbortSignal

```ts
const controller = new AbortController();

const response = await client.chat(
  {
    model: "shingitai-mock",
    messages: [{ role: "user", content: "Hello" }],
  },
  { signal: controller.signal },
);
```

Set `timeoutMs` on the client for request timeout behavior. Pass `signal` per
request when the calling application owns cancellation.

## Browser And Node Notes

- Node 18+ is supported because it provides global `fetch`.
- Browsers are supported when CORS and application auth policy allow calls.
- Runtimes without global `fetch` can pass a custom `fetch` implementation.
- No bundler is required; the package is ESM-first and emits declarations.

## Security Notes

- Do not hardcode API keys.
- Do not commit `.sgt_local_api_key` or `.sgt_current_api_key`.
- Do not log request headers containing Bearer tokens.
- Keep local and staging keys separate.
- Private docs and project memory are not automatically sent by the SDK.
